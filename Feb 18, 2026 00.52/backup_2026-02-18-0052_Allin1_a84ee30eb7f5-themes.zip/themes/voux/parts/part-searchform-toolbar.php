<?php
/**
 * Fullscreen Search Form
 *
 * @package WordPress
 * @subpackage voux
 */
?>

<div id="fullscreen-searchform">
    <button type="button" class="close">×</button>
    <form role="search" method="get" id="searchform" class="" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input type="search" value="<?php the_search_query(); ?>" placeholder="<?php esc_attr_e( 'search for products', 'okthemes' ); ?>" name="s" id="s" />
		<button type="submit" name="submit" id="searchsubmit" class="btn btn-primary"><?php esc_attr_e( 'Search', 'okthemes' ); ?></button>
		<em><?php esc_html_e( 'Press Enter to search', 'okthemes' ); ?></em>
		<input type="hidden" name="post_type" value="product" />
	</form>
</div>
