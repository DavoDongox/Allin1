<?php
//Remove default vc modules
include PARENT_DIR.'/lib/visualcomposer/gg-remove-default.php';

//Default arrays
include PARENT_DIR.'/lib/visualcomposer/default-arrays.php';

include PARENT_DIR.'/lib/visualcomposer/gg-blockquote.php';
include PARENT_DIR.'/lib/visualcomposer/gg-posts.php';
include PARENT_DIR.'/lib/visualcomposer/gg-products-grid.php';
include PARENT_DIR.'/lib/visualcomposer/gg-featured-image.php';
include PARENT_DIR.'/lib/visualcomposer/gg-featured-icon.php';
include PARENT_DIR.'/lib/visualcomposer/gg-title-subtitle.php';
include PARENT_DIR.'/lib/visualcomposer/gg-counter.php';
include PARENT_DIR.'/lib/visualcomposer/gg-contact-form.php';
include PARENT_DIR.'/lib/visualcomposer/gg-timeline-wrapper.php';
include PARENT_DIR.'/lib/visualcomposer/gg-shop-collection.php';
include PARENT_DIR.'/lib/visualcomposer/gg-shop-this-look.php';

//Widgets
include PARENT_DIR.'/lib/visualcomposer/gg-widget-contact-us.php';
include PARENT_DIR.'/lib/visualcomposer/gg-widget-twitter.php';

if (class_exists('MC4WP_Form_Widget')) {
	include PARENT_DIR.'/lib/visualcomposer/gg-widget-mailchimp.php';
}

//Overwrites
include PARENT_DIR.'/lib/visualcomposer/gg-overwrite-image-carousel.php';
include PARENT_DIR.'/lib/visualcomposer/gg-overwrite-image-gallery.php';
include PARENT_DIR.'/lib/visualcomposer/gg-overwrite-single-image.php';
include PARENT_DIR.'/lib/visualcomposer/gg-overwrite-icon.php';
include PARENT_DIR.'/lib/visualcomposer/gg-overwrite-button.php';
include PARENT_DIR.'/lib/visualcomposer/gg-overwrite-cta.php';

//Deregister styles
add_action( 'wp_enqueue_scripts', 'remove_vc_styles', 99 );
function remove_vc_styles() {
	wp_deregister_style( 'nivo-slider-css' );
	wp_deregister_style( 'nivo-slider-theme' );
	wp_deregister_style( 'flexslider' );
	wp_deregister_style( 'prettyphoto' );
	wp_deregister_style( 'isotope-css' );
}

//Deregister scripts
add_action( 'wp_enqueue_scripts', 'remove_vc_scripts', 99 );
function remove_vc_scripts() {
	wp_deregister_script( 'prettyphoto' );
	wp_deregister_script( 'nivo-slider' );
	wp_deregister_script( 'flexslider' );
	wp_deregister_script( 'prettyphoto' );
	wp_deregister_script( 'isotope' );
	wp_deregister_script( 'jcarousellite' );
}

?>