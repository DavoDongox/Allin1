<header class="site-header default" role="banner" id="gg-top">

<nav role="navigation">
    <div class="navbar navbar-default navbar-static-top">
        <div class="flanker dynamic-width"><div class="flanker-holder"><span class="gg-hor-line"></span></div></div>
        <div class="container fixed-width">

            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header col-md-3">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

                <!-- Begin logo -->
                <?php include PARENT_DIR . '/lib/headers/logo.php';?>    
                <!-- End logo -->
            </div>

            <div class="navbar-collapse collapse col-md-9" id="main-navbar-collapse">

                <ul id="toolbar-menu" class="nav navbar-nav">

                <?php if (is_woocommerce_activated()) : ?>
                    <!-- Toolbar: Login/Register -->
                    <?php
                    if( 1 == get_theme_mod( 'header_login_logout', 1 ) ) {
                    if ( is_user_logged_in() ) {
                        $myaccount_page_id = get_option( 'woocommerce_myaccount_page_id' );
                        if ( $myaccount_page_id ) {
                            $logout_url = wp_logout_url( get_permalink( $myaccount_page_id ) );
                            if ( get_option( 'woocommerce_force_ssl_checkout' ) == 'yes' )
                                $logout_url = str_replace( 'http:', 'https:', $logout_url );
                        } else {
                            $logout_url ='?customer-logout=true';
                        }
                    ?>
                        <li><a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('My Account','okthemes'); ?>"><i class="pe-7s-config pe-2x pe-va visible-xs-block"></i><span class="hidden-xs"><?php _e('My Account','okthemes'); ?></span></a></li>
                        <li><a href="<?php echo esc_url($logout_url); ?>" title="<?php _e('Logout','okthemes'); ?>"><i class="pe-7s-power pe-2x pe-va visible-xs-block"></i><span class="hidden-xs"><?php _e('Logout','okthemes'); ?></span></a></li>
                     <?php } else { ?>
                        <li><a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('Login / Register','okthemes'); ?>"><i class="pe-7s-users pe-2x pe-va visible-xs-block"></i><span class="hidden-xs"><?php _e('Login / Register','okthemes'); ?></span></a></li>
                     <?php } } ?>
                     <!-- End Toolbar: Login/Register -->

                     <!-- Toolbar: Cart -->
                    <?php if( 1 == get_theme_mod( 'header_cart', 1 ) ) { ?>
                        <?php 
                        if (function_exists('header_mini_cart')) { 
                            echo header_mini_cart();
                        }
                        ?>
                    <?php } ?>
                    <!-- End Toolbar: Cart -->

                    <!-- Toolbar: Wishlist -->
                    <?php if( 1 == get_theme_mod( 'header_wishlist', 1 ) ) { ?>
                    <?php if ( class_exists( 'YITH_WCWL_Init' ) ) { ?>
                     <li class="gg-woo-wishlist pull-right">
                         <a href="<?php echo esc_url(get_permalink( get_option( 'yith_wcwl_wishlist_page_id' ) ) ); ?>" title="<?php _e('Wishlist','okthemes'); ?>">
                             <i class="pe-7s-like pe-2x pe-va"></i>
                             <span class="hidden-sm hidden-xs"><?php _e('Wishlist','okthemes'); ?></span>
                         </a>
                     </li>
                     <?php } ?>
                     <?php } ?>
                     <!-- End Toolbar: Wishlist -->

                    <!-- Toolbar: Search -->
                    <?php if( 1 == get_theme_mod( 'header_search', 1 ) ) { ?>
                    <li class="gg-toolbar-search pull-right">
                        <a href="#fullscreen-searchform" title="<?php _e('Search','okthemes'); ?>">
                            <i class="pe-7s-search pe-2x pe-va"></i>
                            <span class="hidden-sm hidden-xs"><?php _e('Search','okthemes'); ?></span>
                        </a>
                    </li>
                    <?php } ?>
                    <!-- End Toolbar: Search -->

                <?php endif; ?>

                    <!-- Toolbar: Language selector -->
                    <?php if ( 1 == get_theme_mod( 'header_wpml_box' ) && is_wpml_activated() ) { ?>
                        <li id="flags_language_selector"><?php language_selector_flags(); ?></li>
                    <?php } ?>
                    <!-- End Toolbar: Language selector -->

                    <!-- Toolbar: Currency switcher -->
                    <?php if ( class_exists('woocommerce_wpml') ) { ?>
                    <li class="gg-currency-switcher">
                        <a href="#" data-toggle="dropdown" aria-haspopup="true" class="dropdown-toggle">
                            <span><?php echo get_woocommerce_currency(); ?></span>
                        </a>
                        <?php do_action('currency_switcher', array('format' => '%name%', 'switcher_style' => 'list', 'orientation' => 'vertical')); ?>
                    </li>
                    <?php } ?>
                    <!-- End Toolbar: Currency switcher -->

                </ul>

                <!-- Begin Main Navigation -->
                <?php
                wp_nav_menu(
                    array(
                        'theme_location'    => 'main-menu',
                        'container'         => '',
                        'container_class'   => '',
                        'menu_class'        => 'nav navbar-nav',
                        'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                        'menu_id'           => 'main-menu',
                        'walker'            => new wp_bootstrap_navwalker()
                    )
                ); ?>
                <!-- End Main Navigation -->
            </div>
        </div>
        <div class="flanker dynamic-width"><div class="flanker-holder"><span class="gg-hor-line"></span></div></div>
    </div>
</nav>

<?php gg_page_header(); ?>

</header>
<!-- End Header. Begin Template Content -->