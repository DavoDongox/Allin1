<?php
class WPBakeryShortCode_gg_Widget_MailChimp extends WPBakeryShortCode {

   public function __construct() {  
         add_shortcode('widget_mailchimp', array($this, 'gg_widget_mailchimp'));  
   }

   public function gg_widget_mailchimp( $atts, $content = null ) { 

         $output = $title = '';
         extract(shortcode_atts(array(
             'title'        => '',
             'extra_class' => ''
         ), $atts));

         
         $output = '<div class="vc_widget vc_widget_mailchimp '.$extra_class.'">';
         $type = 'MC4WP_Form_Widget';
         $args = array();

         ob_start();
         the_widget( $type, $atts, $args );
         $output .= ob_get_clean();

         $output .= '</div>';

         return $output;
   }
}

$WPBakeryShortCode_gg_Widget_MailChimp = new WPBakeryShortCode_gg_Widget_MailChimp();


vc_map( array(
   "name" => __("Widget: MailChimp", "okthemes"),
   "description" => __('Display a MailChimp newsletter form', 'okthemes'),
   "base" => "widget_mailchimp",
   "category" => __('OKThemes', 'okthemes'),
   "params" => array(
      array(
         "type" => "textfield",
         "heading" => __("Title", "okthemes"),
         "param_name" => "title",
         "description" => __("Insert title here", "okthemes")
      ),
      array(
         "type" => "textfield",
         "heading" => __("Extra class", "okthemes"),
         "param_name" => "extra_class",
         "description" => __("Insert an extra class to style the widget differently. This widget has already a class styled for dark background: contact_widget_dark ", "okthemes")
      ),

   )
) );

?>