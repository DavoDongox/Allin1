<?php
$output = $title =  $onclick = $custom_links = $img_size = $custom_links_target = $images = $el_class = $partial_view = '';
$mode = $slides_per_view = $wrap = $autoplay = $hide_pagination_control = $hide_prev_next_buttons = $speed = '';
extract(shortcode_atts(array(
    'title' => '',
    'onclick' => 'link_image',
    'custom_links' => '',
    'custom_links_target' => '',
    'img_size' => 'fullsize',
    'customsize_width' => '',
    'customsize_height' => '',
    'images' => '',
    'el_class' => '',
    'mode' => 'horizontal',
    'slides_per_view' => '1',
    'transition_style' => 'fade',
    'wrap' => '',
    'autoplay' => '',
    'hide_pagination_control' => '',
    'hide_prev_next_buttons' => '',
    'speed' => '200',
    'partial_view' => '',
    'css_animation'         => '',
    'img_style' => 'default',
    'hidden_items' =>'',
    'mousewheel'   => ''
), $atts));

$gal_images = '';
$link_start = '';
$link_end = '';
$el_start = '';
$el_end = '';
$slides_wrap_start = '';
$slides_wrap_end = '';
$has_magnific = '';
$img_style_class = $img_style;

$el_class = $this->getExtraClass($el_class);
$css_animation = $this->getCSSAnimation($css_animation);

if ( $onclick == 'link_image' ) {
        
    //Load Magnific
    wp_enqueue_script( 'magnific' );
    wp_enqueue_style( 'magnific' );

    $has_magnific = 'has_magnific';
}

//Load carousel
wp_enqueue_script( 'slickcarousel' );

//Load mousewheel
if ($mousewheel == 'true') {
    wp_enqueue_script( 'mousewheel' );
}


if ( $images == '' ) $images = '-1,-2,-3';

if ( $onclick == 'custom_link' ) { $custom_links = explode( ',', $custom_links); }

$images = explode( ',', $images);
$i = -1;
$css_class =  apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'wpb_images_carousel '.$css_animation.' wpb_content_element'.$el_class.' clearfix', $this->settings['base']);
$carousel_id = 'vc-images-carousel-'.WPBakeryShortCode_VC_images_carousel::getCarouselIndex();
//$slider_width = $this->getSliderWidth($img_size) * $slides_per_view.'px';
//$slider_width = $slider_width * $slides_per_view; //modified

if ($hidden_items) {
    $hidden_items_cls = ' show_hidden_items';
} else {
    $hidden_items_cls = '';
}

?>

<div class="<?php echo apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $css_class, $this->settings['base']) ?>">
    <div class="wpb_wrapper">
        <?php echo  wpb_widget_title(array('title' => $title, 'extraclass' => 'wpb_gallery_heading')) ?>
        <div id="<?php echo esc_attr($carousel_id); ?>" data-mousewheel="<?php echo esc_attr($mousewheel); ?>"
            class="gg-slick-carousel <?php echo esc_attr($has_magnific.$hidden_items_cls); ?>"
            data-slick='{"slidesToShow": <?php echo esc_attr($slides_per_view); ?>, "slidesToScroll": 1, "arrows": <?php echo $hide_prev_next_buttons !== 'yes' ? 'true' : 'false' ?>, "infinite": true, "dots": <?php echo $hide_pagination_control !== 'yes' ? 'true' : 'false' ?>, "autoplay": <?php echo $autoplay === 'yes' ? 'true' : 'false' ?>, "rtl": <?php echo is_rtl() ? 'true' : 'false' ?>, "responsive": [{"breakpoint": 600, "settings": {"slidesToShow": 2, "slidesToScroll": 1}}, {"breakpoint": 480, "settings": {"slidesToShow": 1, "slidesToScroll": 1}}]  }'>
            <!-- Wrapper for slides -->

                    <?php foreach($images as $attach_id): ?>
                    <?php
                    $i++;
                    if ($attach_id > 0) {
                        $attachment_url = wp_get_attachment_url($attach_id , 'full');
                        $alt_text = get_the_title($attach_id);
                        if ($img_size !== 'fullsize') {
                            $thumbnail = '<img class="wp-post-image '.esc_attr($img_style_class).'" src="'.gg_aq_resize( $attach_id, $customsize_width, $customsize_height, true, true ).'" alt="'.esc_html($alt_text).'" />';
                        } else {
                            $thumbnail = '<img class="wp-post-image '.esc_attr($img_style_class).'" src="'.esc_url($attachment_url).'" alt="'.esc_html($alt_text).'" />';          
                        }
                    }

                    ?>
                    <div class="item <?php echo $slides_per_view === '1' ? 'single-image' : '' ?>">

                        <?php if ( $onclick == 'link_image' ) {

                        $link_start = '<a class="lightbox-el" href="'.esc_url($attachment_url).'">';
                        $link_end = '</a>';

                        } elseif ( $onclick == 'custom_link' && isset( $custom_links[$i] ) && $custom_links[$i] != '' ) {
                            $link_start = '<a href="'.esc_url($custom_links[$i]).'"' . (!empty($custom_links_target) ? ' target="'.$custom_links_target.'"' : '') . '>';
                            $link_end = '</a>';
                        }
                        
                        $gal_images = $el_start . $link_start . $thumbnail . $link_end . $el_end;
                        echo  $gal_images;
                        ?>

                    </div>
                    <?php endforeach; ?>

        </div>

    </div><?php echo esc_html( $this->endBlockComment('.wpb_wrapper') ); ?>
</div><?php echo esc_html( $this->endBlockComment('.wpb_images_carousel') ); ?>