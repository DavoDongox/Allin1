<?php
add_action( 'vc_after_init', 'add_cta_btn_colors' ); /* Note: here we are using vc_after_init because WPBMap::GetParam and mutateParame are available only when default content elements are "mapped" into the system */
function add_cta_btn_colors() {
  //Get current values stored in the type param in "Call to Action" element
  $param = WPBMap::getParam( 'vc_cta_button2', 'color' );
  //Append new value to the 'value' array
  $param['value'][__( 'Voux-Primary color', 'okthemes' )] = 'voux-primary-color';
  $param['value'][__( 'Voux-Secondary color', 'okthemes' )] = 'voux-secondary-color';
  //Finally "mutate" param with new values
  vc_update_shortcode_param( 'vc_cta_button2', $param );
}